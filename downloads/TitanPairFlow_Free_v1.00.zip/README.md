# Titan PairFlow MT5: free demo trial v1.00

Copyright (c) 2026 Kirk Manahan (Cryptopayment). All rights reserved. Unauthorized copying, redistribution, decompilation or resale is prohibited.

**Trial limits:** demo accounts only, 1 pair, 0.01 lot per leg. It expires 30 days after the build date.
The Pro version (up to 20 pairs, live accounts) is available with USDT (TRC-20) on the website. An MQL5 Market listing is coming soon.

## Install
1. In MT5, choose File > Open Data Folder.
2. Copy `TitanPairFlow_Free.ex5` to `MQL5\Experts\`.
3. Copy `TitanPairFlowZ.ex5` (the spread-index window) to `MQL5\Indicators\`.
4. Refresh the Navigator, drag Titan PairFlow FREE onto a chart on a **demo** account, and enable Algo Trading.

## How it works
For a pair A/B, the EA regresses ln(A) on ln(B) over `InpLookback` closed bars of `InpTF`. This gives the hedge ratio (beta) and the correlation. The spread is ln(A) - beta*ln(B), and z shows how far the spread is from its mean in standard deviations.
- **Entry:** when |z| ≥ `InpEntryZ`, it buys or sells A and hedges with B.
- **Exit:** when the spread reverts (|z| ≤ `InpExitZ`), on the z stop, on the time stop, on the basket money TP/SL, or when the loss guard triggers.
- **Stop loss:** orders carry no broker-side stop loss. The EA manages all exits, so keep MT5 running.

## Dashboard
The dashboard has an AUTO PILOT / MANUAL toggle and CLOSE ALL. Each pair has buttons for L (long spread), S (short spread), X (close) and Z (spread window). You can search for symbols, then use ADD PAIR.

## Risk disclaimer
Pair trading does not remove market risk:
- correlations break down
- spreads can trend instead of reverting
- costs on two legs, swaps, gaps and slippage add up

No performance is claimed or implied, and the EA has not been backtested by the author. It is for demo testing only. Trading leveraged products can lose all of your capital.

## Licence
This trial is licensed, not sold, for one user on demo accounts. By installing it you accept the End-User Licence Agreement in `EULA.md` (included in this zip): no redistribution, resale or decompiling, no warranty, and you carry all trading risk.
