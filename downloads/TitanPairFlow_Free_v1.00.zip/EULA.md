# End-User Licence Agreement (EULA)

Copyright (c) 2026 Kirk Manahan (Cryptopayment). All rights reserved.
Products: Aurum Titan Prop, Aurum Titan Direction, Titan PairFlow Pro, Titan PairFlow Free Trial, Gold Grid Escape (the "Software").

1. **Licence.** On payment (or, for the free trial, on download) you get a personal, non-exclusive, non-transferable licence for one user. Direct-sale copies run only on the MT5 trading account number they were issued for, until the expiry date if one applies. MQL5 Market copies follow the MQL5 Market rules and the activations MQL5 grants. The free trial is for evaluation on demo accounts only and stops working when the trial period ends.
2. **Ownership.** The Software is licensed, not sold. All rights, title and intellectual property stay with the author.
3. **Restrictions.** You may not copy (except for your own backup), share, redistribute, resell, rent, sublicense or publish the Software or your licence key. You may not decompile, disassemble, reverse-engineer or modify it, or remove or bypass the account lock, licence key, trial limit or copyright notices, except where the law expressly allows this and cannot be excluded by contract.
4. **Termination.** The licence ends automatically if you break these terms. You must then delete all copies.
5. **No warranty.** The Software is provided "as is", without warranty of any kind, express or implied, including fitness for a particular purpose, profitability or uninterrupted operation.
6. **Trading risk.** Trading forex, gold, CFDs and other leveraged products is high risk and you can lose all of your capital. Grid and averaging methods can cause large losses. Past or simulated results do not guarantee future results. Nothing in the Software or its documentation is financial advice. You alone decide whether to use the Software and are responsible for all trades, settings and results. Test on a demo account first and check your broker's and prop firm's rules.
7. **Limitation of liability.** To the extent the law allows, the author is not liable for any trading losses or for any direct, indirect or consequential damages arising from use of, or inability to use, the Software.
8. **Acceptance.** By installing or using the Software you accept these terms.

Contact: https://www.mql5.com/en/users/cryptopayment
